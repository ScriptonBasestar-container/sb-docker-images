<?php
/**
 * This file is exception of wrong instance.
 *
 * PHP version 7
 *
 * @category    ToggleMenu
 * @package     Xpressengine\ToggleMenu
 * @author      XE Developers <developers@xpressengine.com>
 * @copyright   2020 Copyright XEHub Corp. <https://www.xehub.io>
 * @license     http://www.gnu.org/licenses/lgpl-3.0-standalone.html LGPL
 * @link        https://xpressengine.io
 */

namespace Xpressengine\ToggleMenu\Exceptions;

use Xpressengine\ToggleMenu\ToggleMenuException;

/**
 * 메뉴아이템 instance 가 유효하지 않은 경우
 *
 * @category    ToggleMenu
 * @package     Xpressengine\ToggleMenu
 * @author      XE Developers <developers@xpressengine.com>
 * @copyright   2020 Copyright XEHub Corp. <https://www.xehub.io>
 * @license     http://www.gnu.org/licenses/lgpl-3.0-standalone.html LGPL
 * @link        https://xpressengine.io
 */
class WrongInstanceException extends ToggleMenuException
{
    protected $message = 'Wrong instance.';
}
